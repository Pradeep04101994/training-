package com.product.util;

public interface Constants {
	String DRIVERNAME = "com.mysql.jdbc.Driver";
	String URL = "jdbc:mysql://localhost:3306/ecommerce";
	String UID = "root";
	String PASS = "1234";

}
