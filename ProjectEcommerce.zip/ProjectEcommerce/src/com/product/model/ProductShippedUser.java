package com.product.model;

public class ProductShippedUser {
	private int shipmentId;
	private int orderId;
	private int productId;
	private int courierId;
	private String productName;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + courierId;
		result = prime * result + orderId;
		result = prime * result + productId;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + shipmentId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductShippedUser other = (ProductShippedUser) obj;
		if (courierId != other.courierId)
			return false;
		if (orderId != other.orderId)
			return false;
		if (productId != other.productId)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (shipmentId != other.shipmentId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Product Shipped [shipmentId=" + shipmentId + ", orderId=" + orderId + ", productId=" + productId
				+ ", courierId=" + courierId + ", productName=" + productName + "]";
	}
	public int getShipmentId() {
		return shipmentId;
	}
	public void setShipmentId(int shipmentId) {
		this.shipmentId = shipmentId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getCourierId() {
		return courierId;
	}
	public void setCourierId(int courierId) {
		this.courierId = courierId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

}
