package com.product.model;

import java.util.List;

public class SearchResult {
	private int pageNumber;
	private int recordsPerPage ;
	private List<Orders> orders ;
	private int totalCount ; 
	
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalOrders) {
		this.totalCount = totalOrders;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getRecordsPerPage() {
		return recordsPerPage;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		result = prime * result + pageNumber;
		result = prime * result + recordsPerPage;
		result = prime * result + totalCount;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SearchResult other = (SearchResult) obj;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		if (pageNumber != other.pageNumber)
			return false;
		if (recordsPerPage != other.recordsPerPage)
			return false;
		if (totalCount != other.totalCount)
			return false;
		return true;
	}
	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}
	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "SearchResult [pageNumber=" + pageNumber + ", recordsPerPage=" + recordsPerPage + ", "
				+ (orders != null ? "orders=" + orders + ", " : "") + "totalOrders=" + totalCount + "]";
	}
	
	
}
