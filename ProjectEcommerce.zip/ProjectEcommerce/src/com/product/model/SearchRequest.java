package com.product.model;

public class SearchRequest {

	private int userId;
	private int pageNumber;
	private int recordsPerPage;
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getRecordsPerPage() {
		return recordsPerPage;
	}
	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}
	@Override
	public String toString() {
		return "SearchRequest [userId=" + userId + ", pageNumber=" + pageNumber + ", recordsPerPage=" + recordsPerPage
				+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + pageNumber;
		result = prime * result + recordsPerPage;
		result = prime * result + userId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SearchRequest other = (SearchRequest) obj;
		if (pageNumber != other.pageNumber)
			return false;
		if (recordsPerPage != other.recordsPerPage)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
	
}
