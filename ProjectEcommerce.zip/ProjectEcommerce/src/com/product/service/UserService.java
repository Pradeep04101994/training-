package com.product.service;

import java.util.List;
import java.util.Map;

import com.product.model.Address;
import com.product.model.SearchRequest;
import com.product.model.SearchResult;
import com.product.model.User;
import com.product.storage.UserStorage;

public class UserService {

	UserStorage storage = new UserStorage();

	public List<User> getUserDetailsfromCity(String city) throws Exception {
		List<User> users = storage.getUserDetailsfromCity(city);
		return users;
	}

	public List<Map<String, Integer>> getUserCountByCity(String cityName) throws Exception {
		List<Map<String, Integer>> listMap = storage.getUserCountByCity(cityName);
		return listMap;
	}

	public User updateUserEmail(String userName, String email) throws Exception {
		return storage.updateUserEmail(userName, email);
	}

	public User insertAddressForUser(Address address) throws Exception {
		int userId = storage.insertAddressForUser(address);
		return storage.getUserDetailsByid(userId);
	}

	public User createUser(User user) throws Exception {
		int userId = storage.createUser(user);
		return storage.getUserDetailsByid(userId);
	}

	public boolean deleteUserById(int userId) throws Exception {
		userId = storage.deleteUserById(userId);
		return true;
	}

	public SearchResult listOrdersOfUser(SearchRequest req) throws Exception {
		int lineNumber = (req.getRecordsPerPage() * (req.getPageNumber() - 1));

		return storage.listOrdersOfUser(req, lineNumber);

		// TODO Auto-generated method stub

	}
}
