package com.product.service;

import java.util.List;
import java.util.Map;

import com.product.model.BrandCategoryProductCount;
import com.product.model.Product;
import com.product.model.ProductShippedUser;
import com.product.storage.ProductStorage;

public class ProductService {

	
	ProductStorage storage = new ProductStorage();

	public double getAvgPriceofProducts() throws Exception {
		return storage.getAvgPriceofProducts();
	}

	public List<Product> getProductsLike(String like) throws Exception {
		return storage.getProductsLike(like);
	}

	public double getProductsBetweenPrice(int from, int to) throws Exception {
		return storage.getProductsBetweenPrice(from, to);

	}

	public List<Map<String, Integer>> getProductsShippedFromMonth(String from, String to) throws Exception {
		return storage.getProductsShippedFromMonth(from, to);
	}

	public List<Map<Integer, String>> getShipmentStatus() throws Exception {
		return storage.getShipmentStatus();
	}

	public List<Map<String, Integer>> getCountOfProductsOfEachCategory() throws Exception {
		return storage.getCountOfProductsOfEachCategory();
	}

	public List<BrandCategoryProductCount> getBrandCategoryProductCount() throws Exception {
		return storage.getBrandCategoryProductCount();
	}

	public List<ProductShippedUser> getProductShippedUser() throws Exception {
		return storage.getProductShippedUser();
	}

	public List<Map<String, Integer>> getProductCountMonthwise() throws Exception {
		return storage.getProductCountMonthwise();
	}

	public List<Map<String, Integer>> getProductCountFromCity(String first, String second) throws Exception {
		return storage.getProductCountFromCity(first, second);
	}

}
