package com.product.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.product.model.Address;
import com.product.model.Orders;
import com.product.model.SearchRequest;
import com.product.model.SearchResult;
import com.product.model.User;
import com.product.util.JDBCHelper;

public class UserStorage {

	private final String INSERT_INTO_USER = "INSERT INTO user (`name`, `password`, `email`, `mobile`) VALUES (?, ?, ?, ?);";
	private final String FIND_USER_BY_ID = "SELECT * FROM user WHERE id = ?";
	private final String FIND_USER_ADDRESS = "SELECT * FROM address WHERE user_id = ? AND city = ?";
	private final String FIND_USER = "SELECT * FROM user ";
	private final String FIND_USER_COUNT_CITY = "SELECT u.name ,COUNT(o.id)'count' FROM  user u ,address a , orders o WHERE u.id = a.user_id AND u.id = o.id AND a.city = ? GROUP BY u.name ";
	private final String UPDATE_USER_EMAIL = "UPDATE user u SET u.email = ? WHERE u.name = ? ";
	private final String FIND_USER_BY_NAME = "SELECT * FROM user WHERE name = ? ";
	private final String INSERT_ADDRESS_FOR_USER = "INSERT INTO address (`city`, `state`, `street`, `houseNumber`, `user_id`) VALUES ( ?, ?, ?, ?, ?)";
	private final String DELETE_USER_BY_ID = "DELETE FROM `user` WHERE `id`= ?";

	/**
	 * 
	 * @param city
	 * @return
	 * @throws Exception
	 */
	public List<User> getUserDetailsfromCity(String city) throws Exception {

		List<User> users = new ArrayList<User>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		User user = null;
		List<Address> add = null;

		try {
			con = JDBCHelper.getConnection();

			ps = con.prepareStatement(FIND_USER);
			rs = ps.executeQuery();

			while (rs.next()) {

				add = findUserAddress(rs.getInt("id"), city);
				if (add.size() >= 1) {
					user = new User();
					user.setId(rs.getInt("id"));
					user.setName(rs.getString("name"));
					user.setEmail(rs.getString("email"));
					user.setMobile(rs.getString("mobile"));
					user.setAddresses(findUserAddress(user.getId(), city));
					users.add(user);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			JDBCHelper.close(rs);
			JDBCHelper.close(ps);
			JDBCHelper.close(con);
		}

		return users;
	}

	/**
	 * @description find userAddress by their id and city
	 * @param userId
	 * @param city
	 * @return
	 * @throws Exception
	 */
	public List<Address> findUserAddress(int userId, String city) throws Exception {

		ResultSet rs = null;
		Address add = null;
		List<Address> addList = new ArrayList<Address>();
		Connection con = JDBCHelper.getConnection();
		PreparedStatement ps = con.prepareStatement(FIND_USER_ADDRESS);
		ps.setInt(1, userId);
		ps.setString(2, city);
		rs = ps.executeQuery();
		while (rs.next()) {
			add = new Address();
			add.setId(rs.getInt("id"));
			add.setState(rs.getString("state"));
			add.setCity(rs.getString("city"));
			add.setStreet(rs.getString("street"));
			add.setHouseNumber(rs.getString("houseNumber"));
			add.setUserId(rs.getInt("user_id"));
			addList.add(add);
		}

		return addList;
	}

	/**
	 * @description : find user Address by their id
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List<Address> findUserAddress(int userId) throws Exception {

		ResultSet rs = null;
		Address add = null;
		List<Address> addList = new ArrayList<Address>();
		Connection con = JDBCHelper.getConnection();
		PreparedStatement ps = con.prepareStatement("Select * from address where user_id = ? ");
		ps.setInt(1, userId);
		// ps.setString(2, city);
		rs = ps.executeQuery();
		while (rs.next()) {
			add = new Address();
			add.setId(rs.getInt("id"));
			add.setState(rs.getString("state"));
			add.setCity(rs.getString("city"));
			add.setStreet(rs.getString("street"));
			add.setHouseNumber(rs.getString("houseNumber"));
			add.setUserId(rs.getInt("user_id"));
			addList.add(add);
		}

		return addList;
	}

	/**
	 * 
	 * @param cityName
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, Integer>> getUserCountByCity(String cityName) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Map<String, Integer>> listMap = new ArrayList<Map<String, Integer>>();

		try {
			con = JDBCHelper.getConnection();

			ps = con.prepareStatement(FIND_USER_COUNT_CITY);
			ps.setString(1, cityName);
			rs = ps.executeQuery();
			Map<String, Integer> map = null;
			while (rs.next()) {
				map = new HashMap<String, Integer>();
				map.put(rs.getString("name"), rs.getInt("count"));
				listMap.add(map);
			}

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}

		return listMap;

	}

	/**
	 * Update user Email by UserName
	 * 
	 * @param userName
	 * @param email
	 * @return
	 * @throws Exception
	 */
	public User updateUserEmail(String userName, String email) throws Exception {
		Connection con = null;
		PreparedStatement psUpdate = null, psSelect = null;
		ResultSet rs = null;
		User user = null;
		try {
			con = JDBCHelper.getConnection();
			psUpdate = con.prepareStatement(UPDATE_USER_EMAIL);
			psUpdate.setString(1, email);
			psUpdate.setString(2, userName);
			psUpdate.executeUpdate();
			psSelect = con.prepareStatement(FIND_USER_BY_NAME);
			psSelect.setString(1, userName);
			rs = psSelect.executeQuery();

			while (rs.next()) {
				user = new User();
				user.setEmail(rs.getString("email"));
				user.setId(rs.getInt("id"));
				user.setMobile(rs.getString("mobile"));
				user.setName(rs.getString("name"));
				user.setAddresses(findUserAddress(rs.getInt("id")));
			}

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(psUpdate);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return user;
	}

	/**
	 * Insert address for the user
	 * 
	 * @param address
	 * @return
	 * @throws Exception
	 */
	public int insertAddressForUser(Address address) throws Exception {
		Connection con = null;
		PreparedStatement psInsertAddress = null;
		ResultSet rs = null;

		try {
			con = JDBCHelper.getConnection();
			psInsertAddress = con.prepareStatement(INSERT_ADDRESS_FOR_USER);
			psInsertAddress.setString(1, address.getCity());
			psInsertAddress.setString(2, address.getState());
			psInsertAddress.setString(3, address.getStreet());
			psInsertAddress.setString(4, address.getHouseNumber());
			psInsertAddress.setInt(5, address.getUserId());
			psInsertAddress.executeUpdate();

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(psInsertAddress);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return address.getUserId();
	}

	/**
	 * get the user details by id
	 * 
	 * @param id
	 * @return User object
	 * @throws Exception
	 */
	public User getUserDetailsByid(int id) throws Exception {
		Connection con = null;
		PreparedStatement psSel = null;
		ResultSet rs = null;
		User user = null;
		try {
			con = JDBCHelper.getConnection();
			psSel = con.prepareStatement(FIND_USER_BY_ID);
			psSel.setInt(1, id);
			rs = psSel.executeQuery();
			while (rs.next()) {
				user = new User();
				user.setEmail(rs.getString("email"));
				user.setId(rs.getInt("id"));
				user.setMobile(rs.getString("mobile"));
				user.setName(rs.getString("name"));
				user.setAddresses(findUserAddress(rs.getInt("id")));
			}
		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(psSel);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return user;
	}

	/**
	 * method to create user
	 * 
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public int createUser(User user) throws Exception {
		Connection con = null;
		PreparedStatement psInsertUser = null;
		ResultSet rs = null;
		int id = 0;

		try {
			con = JDBCHelper.getConnection();
			con.setAutoCommit(false);
			psInsertUser = con.prepareStatement(INSERT_INTO_USER);
			psInsertUser.setString(1, user.getName());
			psInsertUser.setString(2, user.getPassword());
			psInsertUser.setString(3, user.getEmail());
			psInsertUser.setString(4, user.getMobile());
			psInsertUser.executeUpdate();

			con.commit();
			rs = psInsertUser.getGeneratedKeys();
			if (rs.next()) {
				id = rs.getInt(1);
			}
			System.out.println("id = " + id);

		} catch (Exception e) {
			if (con != null) {
				con.rollback();
				System.out.println("Connection Rollback ");
			}

			throw e;
		} finally {
			con.setAutoCommit(true);
			JDBCHelper.close(psInsertUser);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return id;
	}

	/**
	 * method to delete user by id
	 * 
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public int deleteUserById(int userId) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = JDBCHelper.getConnection();
			ps = con.prepareStatement(DELETE_USER_BY_ID);
			ps.setInt(1, userId);
			ps.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(con);

		}
		return userId;
	}

	/**
	 * list the orders of a user by page number and number of records per page
	 * 
	 * @param req
	 * @param lineNumber
	 * @return
	 * @throws Exception
	 */
	public SearchResult listOrdersOfUser(SearchRequest req, int lineNumber) throws Exception {
		Connection con = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		List<Orders> orderList = new ArrayList<Orders>();
		Orders order = null;
		SearchResult result = new SearchResult();
		int count = 0;
		try {
			con = JDBCHelper.getConnection();

			ps = con.prepareStatement("SELECT * FROM orders WHERE user_id=? LIMIT ?,?");
			ps.setInt(1, req.getUserId());
			ps.setInt(2, lineNumber);
			ps.setInt(3, req.getRecordsPerPage());
			rs = ps.executeQuery();

			while (rs.next()) {
				order = new Orders();
				order.setOrderId(rs.getInt("id"));
				order.setUserId(rs.getInt("user_id"));
				order.setProductId(rs.getInt("product_id"));
				order.setOrderDate(rs.getTimestamp("order_date"));
				orderList.add(order);
			}

			ps1 = con.prepareStatement("SELECT count(*)count FROM orders WHERE user_id = ?");
			ps1.setInt(1, req.getUserId());
			rs1 = ps1.executeQuery();
			if (rs1.next()) {
				count = rs1.getInt("count");
			}

			result.setPageNumber(req.getPageNumber());
			result.setRecordsPerPage(req.getRecordsPerPage());
			result.setOrders(orderList);
			result.setTotalCount(count);

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps1);
			JDBCHelper.close(ps);
			JDBCHelper.close(rs1);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return result;
	}
}
