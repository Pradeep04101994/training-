package com.product.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.product.model.BrandCategoryProductCount;
import com.product.model.Product;
import com.product.model.ProductShippedUser;
import com.product.util.JDBCHelper;

public class ProductStorage {
	
	private final String FIND_AVERAGE_PRICE = "SELECT AVG(price)'AveragePrice' FROM product";
	private final String FIND_PRODUCTS_LIKE = "SELECT * FROM product WHERE product.name LIKE ? ";
	private final String FIND_PRODUCTS_BETWEEN_PRICE = "SELECT SUM(price)'price' FROM product WHERE price BETWEEN ? AND ?";
	private final String FIND_PRODUCTS_SHIPPED_MONTH = "SELECT  COUNT(*)'count',p.name'name' FROM product p , orders o WHERE p.id = o.product_id AND o.order_date  BETWEEN ? AND ? GROUP BY p.name  ";
	private final String FIND_SHIPMENT_STATUS = " SELECT orders.id'orderID' , shipment.status FROM orders , shipment WHERE orders.id = shipment.order_id ORDER BY  orders.id ";
	private final String FIND_PRODUCT_COUNT_CATEGORY ="SELECT COUNT(*)'NumberofProducts', category.name'CategoryName' FROM product , category WHERE category.id = product.category_id GROUP BY category.name ";
	private final String FIND_BRAND_CATEGORY_PRODUCT_COUNT = "SELECT  * , COUNT(productName) prodCount FROM (SELECT b.name brandName,c.name categoryName,p.name productName FROM product p,category c,brand b WHERE p.brand_id=b.id AND p.category_id=c.id) pcb GROUP BY brandName,categoryName";
	private final String FIND_PRODUCT_SHIPPED_USER = " SELECT  s.id'shipmentID' , o.id'orderID' , p.id'productID'  ,c.id'courierID',p.name'productName' FROM  product p , orders o , shipment s ,courier c WHERE s.status = 'delivered' AND s.order_id = o.id AND o.product_id = p.id AND s.courier_id = c.id";
	private final String FIND_PRODUCT_COUNT_MONTHWISE = "SELECT monthname(o.order_date)'month',COUNT(p.id)'numberOfProducts' FROM product p INNER JOIN orders o on p.id = o.product_id AND order_date  GROUP BY MONTH(o.order_date) ";
	private final String FIND_PRODUCT_FROM_CITY = "SELECT monthname(o.order_date)'month',COUNT(o.id)'numberOfProducts' FROM user u,(SELECT DISTINCT user_id,city FROM address) a,orders o,product p  WHERE u.id=a.user_id AND u.id=o.user_id  AND p.id=o.product_id AND a.city IN( ? , ?) GROUP BY a.city,MONTH(o.order_date);";
	/**
	 * @return list of users
	 * @throws Exception
	 */
	
	
	public double getAvgPriceofProducts() throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		double i = 0;
		;

		try {
			con = JDBCHelper.getConnection();
			ps = con.prepareStatement(FIND_AVERAGE_PRICE);
			rs = ps.executeQuery();

			if (rs.next()) {
				i = rs.getDouble("AveragePrice");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return i;

	}

	
	public List<Product> getProductsLike(String like) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Product prod = null;
		List<Product> products = new ArrayList<Product>();

		try {
			con = JDBCHelper.getConnection();
			ps = con.prepareStatement(FIND_PRODUCTS_LIKE);
			ps.setString(1, "%"+like+"%");
			rs = ps.executeQuery();

			while (rs.next()) {
				prod = new Product();
				prod.setId(rs.getInt("id"));
				prod.setName(rs.getString("name"));
				prod.setPrice(rs.getDouble("price"));
				prod.setQuantity(rs.getInt("quantity"));
				prod.setDescription(rs.getString("description"));
				prod.setBrandId(rs.getInt("brand_id"));
				prod.setCategoryId(rs.getInt("category_id"));
				products.add(prod);
			}

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}

		return products;
	}

	public double getProductsBetweenPrice(int i,int j) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Double d = null;

		try {
			con = JDBCHelper.getConnection();
			ps = con.prepareStatement(FIND_PRODUCTS_BETWEEN_PRICE);
			ps.setInt(1, i);
			ps.setInt(2, j);
			rs = ps.executeQuery();
			if (rs.next()) {
				d = (double) rs.getInt("price");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return d;
	}

	public List<Map<String, Integer>> getProductsShippedFromMonth(String from,String to) throws Exception {
		
		Timestamp fromTime = Timestamp.valueOf(from);
		Timestamp toTime = Timestamp.valueOf(to);
		System.out.println("from time = "+ fromTime);
		System.out.println("to time = "+ toTime);
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Map<String, Integer>> listMap = new ArrayList<Map<String, Integer>>();

		try {
			con = JDBCHelper.getConnection();
			System.out.println("Connection has established ");
			System.out.println();
			System.out.println();
			ps = con.prepareStatement(FIND_PRODUCTS_SHIPPED_MONTH);
			ps.setTimestamp(1, fromTime);
			ps.setTimestamp(2, toTime);
			rs = ps.executeQuery();
			Map<String, Integer> map = null;
			while (rs.next()) {
				map = new HashMap<String, Integer>();
				map.put(rs.getString("name"), rs.getInt("count"));
				listMap.add(map);
			}

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}

		return listMap;

	}

	public List<Map<Integer, String>> getShipmentStatus() throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Map<Integer, String>> listMap = new ArrayList<Map<Integer, String>>();

		try {
			con = JDBCHelper.getConnection();
			System.out.println("Connection has established ");
			ps = con.prepareStatement(FIND_SHIPMENT_STATUS);
			rs = ps.executeQuery();
			Map<Integer, String> map = null;

			while (rs.next()) {
				map = new HashMap<Integer, String>();
				map.put(rs.getInt("orderID"), rs.getString("status"));
				listMap.add(map);
			}

		} catch (Exception e) {
			throw e;
		}
		finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}

		return listMap;
	}

	public List<Map<String, Integer>> getCountOfProductsOfEachCategory() throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Map<String, Integer>> listMap = new ArrayList<Map<String, Integer>>();

		try {
			con = JDBCHelper.getConnection();
			System.out.println("Connection has established ");
			System.out.println();
			System.out.println();
			ps = con.prepareStatement(FIND_PRODUCT_COUNT_CATEGORY);
			rs = ps.executeQuery();
			Map<String, Integer> map = null;
			while (rs.next()) {
				map = new HashMap<String, Integer>();
				map.put(rs.getString("CategoryName"), rs.getInt("NumberofProducts"));
				listMap.add(map);
			}

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}

		return listMap;
	}

	public List<BrandCategoryProductCount> getBrandCategoryProductCount() throws Exception {

		List<BrandCategoryProductCount> listofbrandCatProdCount = new ArrayList<BrandCategoryProductCount>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		BrandCategoryProductCount brandCatProdCount = null;

		try {
			con = JDBCHelper.getConnection();

			System.out.println("Connection has established ");
			System.out.println();
			System.out.println();
			ps = con.prepareStatement(FIND_BRAND_CATEGORY_PRODUCT_COUNT);
			rs = ps.executeQuery();

			while (rs.next()) {
				
				brandCatProdCount = new BrandCategoryProductCount();
				brandCatProdCount.setBrandName(rs.getString("brandName"));
				brandCatProdCount.setCategoryName(rs.getString("categoryName"));
				brandCatProdCount.setCount(rs.getInt("prodCount"));
				brandCatProdCount.setProductName(rs.getString("productName"));
				listofbrandCatProdCount.add(brandCatProdCount);
			}

		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(rs);
			JDBCHelper.close(ps);
			JDBCHelper.close(con);
		}

		return listofbrandCatProdCount;

	}

	public List<ProductShippedUser> getProductShippedUser() throws Exception {
		List<ProductShippedUser> listofprodShipUser = new ArrayList<ProductShippedUser>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		ProductShippedUser prodShipUser = null;
		try {
			con = JDBCHelper.getConnection();
			ps = con.prepareStatement(FIND_PRODUCT_SHIPPED_USER);
			rs = ps.executeQuery();

			while (rs.next()) {
				prodShipUser = new ProductShippedUser();
				prodShipUser.setCourierId(rs.getInt("courierID"));
				prodShipUser.setOrderId(rs.getInt("orderID"));
				prodShipUser.setProductId(rs.getInt("productID"));
				prodShipUser.setProductName(rs.getString("productName"));
				prodShipUser.setShipmentId(rs.getInt("shipmentID"));
				listofprodShipUser.add(prodShipUser);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		return listofprodShipUser;

	}
	
	public List<Map<String,Integer>> getProductCountMonthwise() throws Exception
	{
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Map<String,Integer>> listofMap = new ArrayList<Map<String,Integer>>();
		try
		{
			con = JDBCHelper.getConnection();
			ps = con.prepareStatement(FIND_PRODUCT_COUNT_MONTHWISE);
			rs = ps.executeQuery();
			
			Map<String,Integer> map = null;
			
			while(rs.next())
			{
				map = new HashMap<String,Integer>();
				map.put(rs.getString("month"), rs.getInt("numberOfProducts"));
				listofMap.add(map);
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}
		
		return listofMap;
		
	}
	
	public List<Map<String,Integer>> getProductCountFromCity(String first, String second) throws Exception
	{
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Map<String,Integer>> listofMap = new ArrayList<Map<String,Integer>>();
		try
		{
			con = JDBCHelper.getConnection();
			ps = con.prepareStatement(FIND_PRODUCT_FROM_CITY);
			ps.setString(1, first);
			ps.setString(2, second);
			rs = ps.executeQuery();
			
			Map<String,Integer> map = null;
			
			while(rs.next())
			{
				map = new HashMap<String,Integer>();
				map.put(rs.getString("month"), rs.getInt("numberOfProducts"));
				listofMap.add(map);
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			JDBCHelper.close(ps);
			JDBCHelper.close(rs);
			JDBCHelper.close(con);
		}

		return listofMap;
	}
}
