package com.product.main;

import com.product.model.Orders;
import com.product.model.SearchRequest;
import com.product.model.SearchResult;
import com.product.service.ProductService;
import com.product.service.UserService;

public class Main {
	// Driver program
	public static void main(String[] args) {

		try {
			ProductService productService = new ProductService();
			UserService userService = new UserService();

			/*
		// 1) query - List all users from a city
		  
		  	/*
		  	 
			  List<User> user = userService.getUserDetailsfromCity("bangalore");
			  Iterator<User> it = user.iterator(); 
			  System.out.println("List of all users from bangalore ");
			   while (it.hasNext()) {
			  System.out.println(it.next()); }
			  
			 */

		//2) query - Find all user who are belong to bangalore and count of their orders
			
			
			  /* 
	
			    List<Map<String, Integer>> listMap =userService.getUserCountByCity("Bangalore"); 
			  Iterator<Map<String, Integer>> it = listMap.iterator(); 
			  System.out.println("Users who belong to bangalore and count of their orders ");
			  while (it.hasNext()) {
			  System.out.println(it.next()); }
			  
			 */

			
		// 3) query - Find the average price of all products.
			
			// System.out.println("Average price of all products ="+productService.getAvgPriceofProducts());

		// 4) query -Products which has the name like phone .
			
			  /*
			   		System.out.println("products name like %phone%");
					List<Product> prod = productService.getProductsLike("phone"); 
				  	Iterator<Product> it = prod.iterator();
				  
				  	while(it.hasNext())
				   	{ System.out.println(it.next()); }
			  */
			

		// 5) query - Find sum of all products between 0 and 1000 .
			
			// System.out.println("Sum of products between given price range is  = " +productService.getProductsBetweenPrice(0,1000));
			
			

		//  6) query - Find all products shipped in the given month
			
			 /*	  LList<Map<String, Integer>> listMap = productService.getProductsShippedFromMonth("2017-03-01 00:00:00","2017-03-28 23:59:59");
			   Iterator<Map<String, Integer>> it = listMap.iterator();
			  while (it.hasNext()) 
			  {
			  	System.out.println(it.next()); 
			  }
			 */
			 
			
		// 7) query - Find all the orders and their shipment status
			
			/*
				  List<Map<Integer, String>> listMap = productService.getShipmentStatus();
				  Iterator<Map<Integer,String>> it = listMap.iterator();
				   while(it.hasNext()) { System.out.println(it.next()); }
			*/

			
		// 8) query - Count all the products of each Category
			/* 
			  List<Map<String, Integer>> listMap = productService.getCountOfProductsOfEachCategory();
			  Iterator<Map<String, Integer>> it = listMap.iterator();
			   while(it.hasNext()) { System.out.println(it.next()); }
			 */

			
		// 9) query - List all Brands and its category with product count . eg..reliance-electronics-10
			  
			  
			 /* 
				  List<BrandCategoryProductCount> listofBrandCategoryProductCount = productService.getBrandCategoryProductCount();
				   Iterator<BrandCategoryProductCount> it = listofBrandCategoryProductCount.iterator();
				  
				  
				  while(it.hasNext()) { System.out.println(it.next()); }
			 */
			 
			
		// 10) query - Find details of a product if it is shipped for a user 
			
			/*
				  List<ProductShippedUser> listofProdShippedUSer =productService.getProductShippedUser();
				   Iterator<ProductShippedUser> it = listofProdShippedUSer.iterator();
				  while(it.hasNext()) { System.out.println(it.next()); }
			 */
			
			
		// 11) query - Calculate count of products ordered in month wise. eg.g jan-2,feb-3
	
			/*
				  
				List<Map<String, Integer>> listofMap = productService.getProductCountMonthwise();
				Iterator<Map<String, Integer>> it1 = listofMap.iterator();
	
				while (it1.hasNext()) {
					System.out.println(it1.next());
				}
				
				
			*/

			  
		// 12) query - Calculate count of products ordered from bangalore and chennai in month wise.
			  
			/*
			 
			  
			  List<Map<String, Integer>> listofMap = productService.getProductCountFromCity("Bangalore","Chennai");
				Iterator<Map<String, Integer>> it1 = listofMap.iterator();

				while (it1.hasNext()) {
					System.out.println(it1.next());
				}
				
			*/
			
			/*
			 *   Additional queries for updating 
			 */
			
		//***** Query to update the userEmail by name 
		
		/*
			User user = userService.updateUserEmail("Pradeep", "pradeep456@gmail.com");
			System.out.println("User Details ");
			System.out.println(user);
		
		*/
			
		//***** Query to insert address for a user 
		/*	
			Address address = new Address();
			address.setCity("chennai");
			address.setState("tamilnadu");
			address.setStreet("ooty");
			address.setHouseNumber("10");
			address.setUserId(1);
			User user = userService.insertAddressForUser(address);
			
			System.out.println("User details after adding the address ..");
			
			System.out.println(user);
		*/	
			
		//***** Query to add an user(user has a address so i am adding the address for the user ) 
			
		/*	
			User user = new User();
			user.setName("krishna");
			user.setPassword("krishna123");
			user.setEmail("krishna@gmail.com");
			user.setMobile("9342945665");
			
			User userAdded = userService.createUser(user);
			
			Address address = new Address();
			address.setCity("chennai");
			address.setState("tamilnadu");
			address.setStreet("ooty");
			address.setHouseNumber("10");
			/*
			 * you will get the user details(including id )get the id and then set user id in setUserId() 
			 */
		//	address.setUserId(userAdded.getId()); 
			
			/*
			 * insert the address for the user created 
			 */
		
		/*	
			userService.insertAddressForUser(address);
			System.out.println("Added user details are ");
			System.out.println(userService.insertAddressForUser(address));
		*/	
			
		//***** delete user by id
			
		/*	
		 
		 boolean sta = userService.deleteUserById(1);
		 if(sta)
			 System.out.println("User deleted successfully"); //I got user deleted successfully for id 1
		 else
			 System.out.println("Error in deleting user ");
	
		*/
		
	//pagination 
			
		SearchRequest req = new SearchRequest();
		req.setUserId(2);
		req.setPageNumber(2);
		req.setRecordsPerPage(2);
		
		SearchResult res = userService.listOrdersOfUser(req);
		System.out.println("count  = " + res.getTotalCount() );
		for (Orders order : res.getOrders()) {
			System.out.println("row  = " + order );
		}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
